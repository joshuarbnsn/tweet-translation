package com.mulesoft.demo.translation.dto.response;

import java.util.List;

public class TranslationResponse {

	List<String> translations;

	public List<String> getTranslations() {
		return translations;
	}

	public void setTranslations(List<String> translations) {
		this.translations = translations;
	}
	
}
